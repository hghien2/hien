const ele = document.getElementById("fix");

ele.style.fontSize = "40px";
